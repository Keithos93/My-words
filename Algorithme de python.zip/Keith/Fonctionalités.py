import random

class Joueur:
    def __init__(self, player):
        self.player = player
        self.i = 0
        self.j = 0

class Jeu:
    def __init__(self):
        self.n = 0
        self.board = []
        self.pawnAlign = 0
        self.playerOne = Joueur(1)
        self.playerTwo = Joueur(2)
        self.playerTurn = self.playerOne
        
    def newBoard(self):
        self.n = int(input("Définissez la taille du plateau (une valeur entre 8 et 12) :"))
        while self.n < 8 or self.n > 12:
            print("La valeur saisie est incorrecte, veuillez réessayer")
            self.n = int(input("Définissez la taille du plateau (une valeur entre 8 et 12) :"))
        self.board = [[0 for i in range(self.n)] for j in range(self.n)]

    def choicePawnsAlign (self):
        self.pawnAlign = int(input("Sélectionner le nombre de pion que vous souhaiter aligner entre 4 et 6: "))
        while self.pawnAlign < 4 or self.pawnAlign > 6:
            print("La valeur saisie est incorrecte")
            self.pawnAlign = int(input("Sélectionner le nombre de pion que vous souhaiter aligner entre 4 et 6: "))

    def displayBoard(self):
            for i in range(self.n):
                print (i+1,end='')
                for j in range(self.n):
                    if self.board[i][j] == 1:
                        print(' O ', end='')
                    elif self.board[i][j] == 2:
                        print(' X ', end='')
                    else:
                        print(' | ', end='')
                    print("", end='')     
                print()
            print(''* self.n, end='')
            print(('----'* self.n))
            print('  ', end='')
            for j in range(self.n):
                print(j+1, end='')
                print('  ', end='')
            print('')

    def chooseWhoBegin(self):
        player = int(input("Qui commence ? 1: Joueur 1, 2: Joueur 2 : "))
        while player != 1 and player!= 2:
            print("La valeur saisie est incorrecte, veuillez réessayer.")
            player = int(input("Qui commence ? 1: Joueur 1, 2: Joueur 2 : "))
        if (player == 1):
            self.playerTurn = self.playerOne
        else:
            self.playerTurn = self.playerTwo


    def selectInitialPosition(self):
        self.playerTurn.i = int(input("Sélectionner l'indice de la ligne où vous souhaitez démarrer : "))
        self.playerTurn.j = int(input("Sélectionner l'indice de la colonne où vous souhaitez démarrer : "))
        self.playerTurn.i = self.playerTurn.i -1
        self.playerTurn.j = self.playerTurn.j -1
        while self.playerTurn.i == 0 or self.playerTurn.j == 0 or self.playerTurn.i >= len(self.board) or self.playerTurn.j >= len(self.board[0]) or self.board[self.playerTurn.i][self.playerTurn.j] != 0 :
            print("Les coordonnées saisies sont incorrectes, veuillez réessayer.")
            self.playerTurn.i = int(input("Sélectionner la ligne de la case où vous souhaitez démarrer"))
            self.playerTurn.j = int(input("Sélectionner la colonne de la case où vous souhaitez démarrer"))
        self.board[self.playerTurn.i][self.playerTurn.j]= self.playerTurn.player  
    def selectMove(self):
        moveRow = int(input("Saisissez les coordonnées de la ligne pour déplacer votre pion (vous ne pouvez vous déplacer qu'en 'L'): ")) - 1
        moveCol = int(input("Saisissez les coordonnées de la colonne pour déplacer votre pion (vous ne pouvez vous déplacer qu'en 'L'): ")) - 1
        
        while moveRow < 0 or moveCol < 0 or moveRow >= len(self.board) or moveCol >= len(self.board[0]) or self.board[moveRow][moveCol] != 0 :
            print("Les coordonnées saisies sont incorrectes, veuillez réessayer.")
            moveRow = int(input("Saisissez les coordonnées de la ligne pour déplacer votre pion (vous ne pouvez vous déplacer qu'en 'L'): ")) - 1
            moveCol = int(input("Saisissez les coordonnées de la colonne pour déplacer votre pion (vous ne pouvez vous déplacer qu'en 'L'): ")) - 1
            
        if moveRow == self.playerTurn.i+2 and moveCol == self.playerTurn.j+1:
            self.board[self.playerTurn.i+2][self.playerTurn.j+1] = self.playerTurn.player
        elif moveRow == self.playerTurn.i+2 and moveCol == self.playerTurn.j-1:
            self.board[self.playerTurn.i+2][self.playerTurn.j-1] = self.playerTurn.player
        elif moveRow == self.playerTurn.i-2 and moveCol == self.playerTurn.j+1:
            self.board[self.playerTurn.i-2][self.playerTurn.j+1] = self.playerTurn.player
        elif moveRow == self.playerTurn.i-2 and moveCol == self.playerTurn.j-1:
            self.board[self.playerTurn.i-2][self.playerTurn.j-1] = self.playerTurn.player
        elif moveRow == self.playerTurn.i+1 and moveCol == self.playerTurn.j-2:
            self.board[self.playerTurn.i+1][self.playerTurn.j-2] = self.playerTurn.player
        elif moveRow == self.playerTurn.i+1 and moveCol == self.playerTurn.j+2:
            self.board[self.playerTurn.i+1][self.playerTurn.j+2] = self.playerTurn.player
        elif moveRow == self.playerTurn.i-1 and moveCol == self.playerTurn.j-2:
            self.board[self.playerTurn.i-1][self.playerTurn.j-2] = self.playerTurn.player
        elif moveRow == self.playerTurn.i-1 and moveCol == self.playerTurn.j+2:
            self.board[self.playerTurn.i-1][self.playerTurn.j+2] = self.playerTurn.player
        else :
            print ("Les coordonnées saisies ne correspondent à un déplacement en 'L', veuillez réessayer.")
            Jeu.selectMove(self)
            return
        self.playerTurn.i=moveRow
        self.playerTurn.j=moveCol
    
    def checkAlignment(self):
        if sum(self.board[self.playerTurn.i][self.playerTurn.j - k] == self.playerTurn.player for k in range(self.pawnAlign)) == self.pawnAlign:
            return True

        if sum(self.board[self.playerTurn.i - k][self.playerTurn.j] == self.playerTurn.player for k in range(self.pawnAlign)) == self.pawnAlign:
            return True
        
        if sum(self.board[self.playerTurn.i - k][self.playerTurn.j - k] == self.playerTurn.player for k in range(self.pawnAlign)) == self.pawnAlign:
            return True

        if sum(self.board[self.playerTurn.i - k][self.playerTurn.j + k] == self.playerTurn.player for k in range(self.pawnAlign)) == self.pawnAlign:
            return True

        return False
    
    def turn(self):
        global player
        if self.playerTurn.player == 1:
            self.playerTurn = self.playerTwo
            print("C'est au tour du joueur 2")
        else:
            self.playerTurn = self.playerOne
            print("C'est au tour du joueur 1")
    
    def isPlayable(self):
        n = self.n

        if self.playerTurn.i - 2 >= 0 and self.playerTurn.j + 1 < n and self.board[self.playerTurn.i - 2][self.playerTurn.j + 1] == 0:
            return True
        elif self.playerTurn.i - 2 >= 0 and self.playerTurn.j - 1 >= 0 and self.board[self.playerTurn.i - 2][self.playerTurn.j - 1] == 0:
            return True
        elif self.playerTurn.i - 1 >= 0 and self.playerTurn.j - 2 >= 0 and self.board[self.playerTurn.i - 1][self.playerTurn.j - 2] == 0:
            return True
        elif self.playerTurn.i - 1 >= 0 and self.playerTurn.j + 2 < n and self.board[self.playerTurn.i - 1][self.playerTurn.j + 2] == 0:
            return True
        elif self.playerTurn.i + 2 < n and self.playerTurn.j + 1 < n and self.board[self.playerTurn.i + 2][self.playerTurn.j + 1] == 0:
            return True
        elif self.playerTurn.i + 2 < n and self.playerTurn.j - 1 >= 0 and self.board[self.playerTurn.i + 2][self.playerTurn.j - 1] == 0:
            return True
        elif self.playerTurn.i + 1 < n and self.playerTurn.j - 2 >= 0 and self.board[self.playerTurn.i + 1][self.playerTurn.j - 2] == 0:
            return True
        elif self.playerTurn.i + 1 < n and self.playerTurn.j + 2 < n and self.board[self.playerTurn.i + 1][self.playerTurn.j + 2] == 0:
            return True

        return False
    

if __name__ == "__main__":
    game = Jeu()
    game.newBoard()
    game.choicePawnsAlign()
    game.displayBoard()
    game.chooseWhoBegin()
    game.selectInitialPosition()
    game.selectMove()
    game.displayBoard()
    game.turn()
    game.selectInitialPosition()
    game.selectMove()
    game.displayBoard()
    game.turn()
    while game.isPlayable() or  not game.checkAlignment():
        game.selectMove()
        game.displayBoard()
        game.turn()