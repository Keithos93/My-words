from tkinter import*
from PIL import Image, ImageTk
import tkinter as tk
from Interface_jeu import PlateauDeJeu, ParametresPartie

def onPlayClick():
    par = ParametresPartie()
    par.creer_interface()
    fenetre.destroy()

fenetre = Tk()
fenetre.geometry("900x600")
fenetre.title("Menu du jeu")
fenetre['bg'] = "black"
fenetre.resizable(height=False, width=False)


image = Image.open("Jeu1.jpg")
photo = ImageTk.PhotoImage(image)
canvas = Canvas(fenetre, width=900, height=600)
canvas.pack()
canvas.create_image(1, 1, anchor=NW, image=photo)


label_menu = Label(canvas, text="Menu Principal", font=("Verdana", 20, "bold"))
label_menu['bg'] = 'Grey' 
label_menu.pack(side= "top", padx= 10, pady= 10)



bouton_jouer = Button(canvas, text='JOUER', font=("Bungee Spice", 20, "bold"), command=onPlayClick)
bouton_jouer['bg'] = 'Turquoise'
bouton_jouer.pack(side="top", padx= 30, pady= 30, )

bouton_options = Button(canvas, text='OPTIONS',font=("Bungee Spice", 20, "bold"))
bouton_options['bg'] = 'Turquoise'
bouton_options.pack(side="top", padx= 35, pady= 35)

bouton_regle = Button(canvas, text='VOIR LES REGLES',font=("Bungee Spice", 20, "bold"))
bouton_regle['bg'] = 'Turquoise'
bouton_regle.pack(side="top", padx= 40, pady= 40)

bouton_exit = Button(canvas, text='EXIT',font=("Bungee Spice", 20, "bold"), command=fenetre.destroy)
bouton_exit['bg'] = 'Turquoise'
bouton_exit.pack(side="top", padx= 45, pady= 45) 








def hover():
    ...

    return hover




fenetre.mainloop()