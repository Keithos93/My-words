import tkinter as tk
from tkinter import ttk
class PlateauDeJeu(tk.Canvas):
    def __init__(self, parent, lignes, colonnes, largeur_case, epaisseur_lignes, *args, **kwargs):
        tk.Canvas.__init__(self, parent, *args, **kwargs)
        self.lignes = lignes
        self.colonnes = colonnes
        self.largeur_case = largeur_case
        self.epaisseur_lignes = epaisseur_lignes
        self.dessiner_plateau()

    def dessiner_plateau(self):

        self.create_rectangle(0, 0, self.colonnes * self.largeur_case, self.lignes * self.largeur_case, fill="black", outline="black")

        
        for ligne in range(self.lignes + 1):
            y = ligne * self.largeur_case
            self.create_line(self.epaisseur_lignes, y, self.colonnes * self.largeur_case - self.epaisseur_lignes, y, fill="white", width=self.epaisseur_lignes)

        for colonne in range(self.colonnes + 1):
            x = colonne * self.largeur_case
            self.create_line(x, self.epaisseur_lignes, x, self.lignes * self.largeur_case - self.epaisseur_lignes, fill="white", width=self.epaisseur_lignes)

            

        
        self.create_line(0, 0, self.colonnes * self.largeur_case, 0, fill="white", width=self.epaisseur_lignes) 
        self.create_line(0, 0, 0, self.lignes * self.largeur_case, fill="white", width=self.epaisseur_lignes) 
        self.create_line(0, self.lignes * self.largeur_case, self.colonnes * self.largeur_case, self.lignes * self.largeur_case, fill="black", width=self.epaisseur_lignes)  
        self.create_line(self.colonnes * self.largeur_case, 0, self.colonnes * self.largeur_case, self.lignes * self.largeur_case, fill="black", width=self.epaisseur_lignes)  

    def dessiner_cercle(self, event):
        
        x = self.canvasx(event.x)
        y = self.canvasy(event.y)

        
        colonne = int(x / self.largeur_case)
        ligne = int(y / self.largeur_case)

        
        x_centre = (colonne + 0.5) * self.largeur_case
        y_centre = (ligne + 0.5) * self.largeur_case

        
        rayon = min(self.largeur_case, self.largeur_case) / 2 - 5  
        self.create_oval(x_centre - rayon, y_centre - rayon, x_centre + rayon, y_centre + rayon, fill="red")


def creerTableau():
    root = tk.Tk()
    root.title("Plateau de jeu")
    root.resizable(width=False, height=False)
    root['bg'] = "black"
    par = ParametresPartie()
    try:
        lignes = int(par.lignes.get())
        colonnes = int(par.colonnes.get())
        largeur_case = 50
        epaisseur_lignes = 3
        if 8 <= lignes <= 12 and 8 <= colonnes <= 12:
            largeur_fenetre = colonnes * largeur_case + epaisseur_lignes * 2
            hauteur_fenetre = lignes * largeur_case + epaisseur_lignes * 2 + 100  
            root.geometry(f"{largeur_fenetre}x{hauteur_fenetre}")

            plateau = PlateauDeJeu(root, lignes, colonnes, largeur_case, epaisseur_lignes,
                                width=colonnes * largeur_case, height=lignes * largeur_case)
            
            plateau.place(x=epaisseur_lignes, y=epaisseur_lignes)

            plateau.bind("<Button-1>", plateau.dessiner_cercle)

            root.mainloop()
        else:
            print("Veuillez entrer des valeurs valides. ")
    except ValueError:
        print("Veuillez entrer des valeurs numériques.")

    
    

class ParametresPartie(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Paramètres de la partie")

        self.lignes = tk.StringVar(value=8)
        self.colonnes = tk.StringVar(value=8)
        self.pions_a_aligner = tk.StringVar(value=4)
        self.commencer_avec = tk.StringVar(value="Joueur 1")

        self.creer_interface()

    def creer_interface(self):
        # Entrée pour le nombre de lignes
        lbl_lignes = ttk.Label(self, text="Lignes :")
        lbl_lignes.grid(row=0, column=0, padx=5, pady=5)
        entry_lignes = ttk.Entry(self, textvariable=self.lignes)
        entry_lignes.grid(row=0, column=1, padx=5, pady=5)

        # Entrée pour le nombre de colonnes
        lbl_colonnes = ttk.Label(self, text="Colonnes :")
        lbl_colonnes.grid(row=1, column=0, padx=5, pady=5)
        entry_colonnes = ttk.Entry(self, textvariable=self.colonnes)
        entry_colonnes.grid(row=1, column=1, padx=5, pady=5)

        # Entrée pour le nombre de pions à aligner pour gagner
        lbl_pions_a_aligner = ttk.Label(self, text="Pions à aligner :")
        lbl_pions_a_aligner.grid(row=2, column=0, padx=5, pady=5)
        entry_pions_a_aligner = ttk.Entry(self, textvariable=self.pions_a_aligner)
        entry_pions_a_aligner.grid(row=2, column=1, padx=5, pady=5)

        # Choix du joueur qui commencera la partie
        lbl_commencer_avec = ttk.Label(self, text="Commencer avec :")
        lbl_commencer_avec.grid(row=3, column=0, padx=5, pady=5)
        radio_joueur1 = ttk.Radiobutton(self, text="Joueur 1", variable=self.commencer_avec, value="Joueur 1")
        radio_joueur1.grid(row=3, column=1, padx=5, pady=5, sticky=tk.W)
        radio_joueur2 = ttk.Radiobutton(self, text="Joueur 2", variable=self.commencer_avec, value="Joueur 2")
        radio_joueur2.grid(row=3, column=1, padx=5, pady=5, sticky=tk.E)

        # Bouton pour valider les paramètres
        bouton_valider = ttk.Button(self, text="Valider", command=creerTableau)
        bouton_valider.grid(row=4, column=0, columnspan=2, pady=10)

        